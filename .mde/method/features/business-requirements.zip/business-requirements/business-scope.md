---
id: business-scope
title: Business scope
origin: mde
impacts:
  - business-requirements
default: n/a
---

# Business scope

## Purpose

Capture what the business needs at a business level, clearly enough to drive design, page
specs, use cases, rules, prototypes, implementation, and tests.

## Impact on business-requirements

Business analysis identifies: business problem/opportunity, business goals, in-scope and
out-of-scope areas, assumptions, constraints, stakeholders/actors, and open questions.
Written to `specs/business/business-overview.md` (scope/goals/assumptions/constraints) with
open + resolved questions in `specs/business/discussion.md`.

## Template impact

- `business-overview` template → scope / goals / assumptions / constraints sections.
- `discussion` template → open + resolved business questions.

## Checks

- Are business problem, goals, in/out-of-scope, assumptions, constraints, stakeholders, and
  open questions all identified (missing/deferred marked explicitly, not pretended complete)?
  · evidence: `specs/business/business-overview.md` + `discussion.md`
  · when: static
