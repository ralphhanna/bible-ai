---
type: feature
id: gherkin-traceability
title: Gherkin traceability
origin: mde
impacts:
  - testing
default: n/a
---

# Gherkin traceability

## Purpose

Each `.feature` scenario traces to an acceptance criterion / test-plan row — and through it to
a use case / API endpoint / page spec.

## Impact on testing

Each `.feature` Scenario traces to an acceptance criterion / test-plan row in `acceptance.md`
(and through it to a use case / API endpoint / page spec). Behavioral dimensions (rules, use
cases, API endpoints, E2E workflows) are covered beyond the line floor.

### Business-rule tests — exercise the rule, prove it discriminates

**The intent:** a business-rule test proves the rule's **logic is actually enforced** by
invoking the **real API** with **both a valid and an invalid scenario**, and asserting the
result of each — evidence that the rule *fires on the disallowed input and lets the allowed
input through*. A test that does only one half proves nothing: a lone reject case can pass
because the API rejects *everything*; a lone accept case never shows the rule exists. **The
proof is the contrast** — same operation, invalid input rejected *for this rule*, valid input
accepted — so each rule gets a **pair** of scenarios, not one.

**Location.** Business-rule scenarios have their own dedicated file, separate from operation
scenarios: a capability's regular `.feature` files (`tests/api/{cap}.feature`) cover its entity
operations; business-rule scenarios go in their **own** file under
`tests/business-rules/{cap}.feature`. This keeps every rule test findable in one place and
mirrors the report/log convention below (`reports/evidence/tests-business-rules/`).

**Each rule requires two scenarios** (a `Scenario Outline` with a valid and an invalid row is
fine), both driving the rule's operation through the real API:

1. **Invalid case — the rule rejects.** Apply concrete input that **violates** the rule
   (stated as a data table / quoted values in the Gherkin) and assert the operation is
   **rejected with a structured error that identifies this rule** — see the API contract
   below. Not "returns a validation response"; the assertion names *which* rule fired.
2. **Valid case — the rule admits.** Apply concrete input that **satisfies** the rule and
   assert the operation **succeeds and its effect is observable** (the record is created /
   the transition happened / the value persisted). This is what proves the reject in (1) was
   the *rule* discriminating, not the endpoint refusing everything.

**The rejection must reference the rule by its concept id (API contract).** The invalid case
asserts on a **structured field** in the error response — a machine-checkable `rule` / `code` /
`violation` field — that carries the rule's **OKF concept id: its full catalogue path minus
`.md`** (e.g. `specs/business/capabilities/project-staffing/business-rules/assignment-conflict-check`),
not a bare slug and not a free-text human message. Asserting a substring of a prose message is
brittle and fakeable; asserting a structured id is specific and stable. This places a
**requirement on the API** (carried into the `api` feature/target): a business-rule rejection
returns a structured error whose body identifies the violated rule by its concept id — the app
is *built* to emit what the test asserts. (A rule reference alone is necessary but not
sufficient — demoX asserts `body.details.rule === slug` yet its tests are useless because they
have no valid case; the id + the valid/invalid contrast together are the proof.)

**Evidence of results.** Both responses (the rejected and the accepted) are captured to the
run log under `reports/evidence/tests-business-rules/` — the status, the structured rule id on the
reject, and the observed effect on the accept — so the rule's enforcement is *evidenced*, not
merely asserted-and-discarded.

**`.feature` files must be EXECUTABLE, not decorative trace artifacts.** A `.feature` file
only satisfies traceability if the scenario actually *runs* — which means the app carries a
Cucumber runner (a `@cucumber/cucumber`/`cucumber-js` dependency), **step definitions** that
drive the real API/UI for those scenarios, and `mde:test` executes the `.feature` files (not
only the Vitest/supertest suites). A `.feature` file present in the manifest with no step
definitions and no invocation from `mde:test` is a **decorative trace file** — it looks like a
test, names the operation, satisfies the presence/naming checks, yet asserts nothing and never
runs. That is drift: the scenario is documentation cosplaying as a test. Presence of `.feature`
files therefore requires the runner + step definitions + `mde:test` wiring to exist alongside
them.

**A scenario must EXERCISE the operation with real data and assert its EFFECT — not scan the
screen.** Naming the operation is not testing it. Each scenario for a **mutating** operation
(create / update / delete / lifecycle transition) must:
1. **Apply concrete input data** — fill real field values (a create fills the form; an update
   changes a specific value; a transition acts on a known record), not merely open/close a
   modal or enter/exit an edit mode without editing.
2. **Assert the operation's observable effect** — the created row now appears in the list with
   the values entered; the updated value is shown back; the deleted row is gone; the lifecycle
   state changed; a stale/invalid write is rejected with the expected error. Asserting only
   that "a toast appeared" or that "an element is visible" is **not** an effect assertion — a
   toast fires on many paths and proves the form *submitted*, not that the operation *worked*
   with this data.

A **read** operation (list / read / search) asserts the **expected data is present** — the
specific records/fields it should return — not merely that the container element rendered.
A scenario that navigates, clicks, and asserts `I should see the "X" element` is **screen
scanning**: it proves the page mounted, not that the operation behaves correctly. Screen-scan
scenarios do not satisfy operation coverage; the scenario for `entity.op` must drive that
operation's real input→effect path.

**The data must be VISIBLE IN THE GHERKIN — living documentation, not a shell over hidden step
data.** A scenario is read by people (that is the point of Gherkin); its **input records and
expected output must appear in the scenario text in plain English**, not be buried in the step
definitions. Concretely:
- **Input** — the record(s) the operation acts on are stated in the step, as a **data table** or
  quoted field values: `When I register an employee: | name | department | email |
  | Web Employee | Engineering | web.employee@example.test |` — not a bare `When I create an
  employee`.
- **Output** — the expected result is a plain-English assertion naming the **actual values**:
  `Then the directory shows "Web Employee" in "Engineering"` — not `Then the result is backed by
  the API` or `Then the create operation succeeds`.
- **Language, not code** — steps read as business behaviour; do **not** leak operation ids into
  the prose (`When I do employee.create` is code cosplaying as English — say `When I register an
  employee`). The `entity.op` trace lives in `acceptance.md` / step wiring, not in the sentence.
- Repeating a scenario over several input rows uses a **Scenario Outline + Examples** table, so
  the data set is visible.

A `.feature` whose scenarios name an operation and assert vaguely ("operations are backed by the
API", "controls are visible") — with the real data hidden in `steps/*.mjs` — fails this even if
the steps do real work: the feature is unreadable as documentation. The data-in and data-out
belong in the scenario.

## Audit

Judge whether the business-rule tests **actually exercise the rule** — whether they would
**catch the rule breaking** — or merely clear the coverage floor while proving nothing. Coverage
cannot see this: a contentless scenario that POSTs *something* through the route still executes
source lines and counts as coverage, so a genuine-coverage verdict says nothing about whether the
rule's logic is tested. This concern is the one coverage can't answer.

For **each** business rule (`specs/business/**/business-rules/<slug>.md`), read its scenarios
under `tests/business-rules/` and the step definitions they bind to, and ask:

- **Is there a valid/invalid PAIR?** An invalid case that drives violating input *and* a valid
  case that drives satisfying input, through the **same operation**. A lone reject is **not
  exercised** — it can pass because the endpoint refuses everything; a lone accept never shows
  the rule exists. The proof is the **contrast**.
- **Does the reject identify THIS rule?** The invalid case must assert on a **structured** error
  field carrying the rule's **concept id** (its catalogue path minus `.md`), not any 422 and not
  a brittle prose-message substring. A test that asserts a bare status code, or `body.details.rule
  === <slug>` with no valid case, is the demoX failure mode: it names the rule yet proves nothing.
- **Does the valid case assert an observable EFFECT?** The operation succeeded and the state
  changed (row created / transition happened / value persisted) — not just "a 2xx" or "a toast".
- **Would flipping the rule off break this test?** The litmus: if the server-side rule check were
  removed, the invalid case must start *failing*. If it wouldn't (the assertion doesn't depend on
  the rule firing), the test is decorative.

Report each rule's BR tests as **exercised** (valid/invalid pair, reject carries the rule's
concept id, valid asserts a real effect — a test that would fail if the rule were disabled) or
**not exercised** (missing a half, vague/contentless assertion, or a rejection that doesn't
identify the rule). A rule whose tests are present and pass the coverage floor is **not**
exercised if removing the rule would leave the tests green.

## Checks

- Does each `.feature` scenario trace to an acceptance-criterion / test-plan row in
  `acceptance.md`?
  · evidence: scenario ↔ acceptance.md rows
  · when: static
- Did a plan implementing API/UI behaviour produce **`.feature` files at all** (Gherkin,
  not only raw supertest/Playwright)?
  · evidence: presence of `.feature` files in the manifest
  · when: static
- Does **every entity operation** — CRUD **and** lifecycle — have its **own Gherkin
  scenario**? Not "the slice has a test": one scenario per declared operation.
  · evidence: a `.feature` scenario naming each `entity.op`
  · when: static
- Does **every business rule** have **both** scenarios — an **invalid** case that drives the
  rule's violating input and asserts a **rejection identifying the rule** (a structured
  `rule`/`code`/`violation` field carrying the rule's concept id), **and** a **valid** case that
  drives satisfying input and asserts the operation **succeeds with an observable effect**? One
  without the other proves nothing: a lone reject can pass because the endpoint refuses
  everything; a lone accept never shows the rule exists. The proof is the **contrast** — same
  operation, invalid rejected *for this rule*, valid admitted. A rule with a spec but no such
  pair is untested (the classic gap: rules defined, none exercised). Naming the rule is not
  testing it.
  · evidence: per business rule (`specs/business/**/business-rules/<slug>.md`), a
    `tests/business-rules/` scenario pair — an invalid case asserting a structured rejection that
    carries the rule's concept id, and a valid case asserting the successful effect
  · when: static (both scenarios present per rule) + requires-environment (the reject fires and
    the accept succeeds when run)
- Does every business-rule scenario live under the **dedicated `tests/business-rules/`
  location** (`tests/business-rules/{capability}.feature`) — not scattered inside each
  capability's regular operation `.feature` files — so every rule test is findable in one
  place, distinct from operation-coverage scenarios?
  · evidence: the covering scenario's file path is under `tests/business-rules/`
  · when: static
- Does each business-rule scenario **state the rule** (its statement or slug in plain English,
  in the scenario name or a `Given`/comment — not just an opaque title), **the sample data
  applied** (the concrete input, as a data table or quoted values — the "data visible in the
  Gherkin" requirement applied to both the violating and the satisfying case), and **the result**
  (invalid → the structured rejection naming the rule's concept id; valid → the observable
  effect)?
  · evidence: scenario text names the rule + carries input data; invalid asserts a structured
    rule-id rejection, valid asserts the concrete effect
  · when: static
- Are the `.feature` files **executable, not decorative** — is there a Cucumber runner
  (`@cucumber/cucumber`/`cucumber-js` dependency), step definitions driving the real API/UI,
  and does `mde:test` actually run the `.feature` files (not only Vitest/supertest)?
  · evidence: `package.json` deps + `mde:test` script; a step-definition dir/files for the
    scenarios; `.feature` files are invoked by the test aggregate
  · when: static (wiring present) + requires-environment (scenarios pass when run)
- Does each **mutating**-operation scenario (create/update/delete/lifecycle) **apply concrete
  input data** and **assert the operation's effect** — the created row appears with the entered
  values, the updated value is shown back, the deleted row is gone, the transition changed
  state, the invalid write is rejected — rather than only opening/closing a modal, entering/
  exiting edit mode, or asserting a toast / an element is visible (screen scanning)?
  · evidence: the scenario's steps — data-entry step(s) present + an outcome assertion on the
    operation's result, not just element visibility
  · when: static
- Does each **read** operation scenario (list/read/search) assert the **expected data is
  present** (the specific records/fields returned), not merely that a container element
  rendered?
  · evidence: the scenario asserts on returned data, not just element presence
  · when: static
- Is the **data visible in the Gherkin** — does each scenario state its **input record(s)**
  (a data table or quoted field values) and assert its **output with the actual values**, in
  plain English, rather than hiding the data in the step definitions or asserting vaguely
  ("operations are backed by the API", "controls are visible")? Does the prose read as business
  behaviour without leaking `entity.op` ids into the sentence?
  · evidence: scenario text carries concrete input data + value-bearing outcome assertions;
    no `entity.op` id or "backed by the API"/"is visible"-only assertions in the steps
  · when: static

```check scope=plan
# Vague-Gherkin smell (deterministic, broadened): a .feature Then-step that asserts only a
# presence/generic phrase — "backed by the API", "is/are visible", "controls are visible",
# "operation(s) succeed(s)", "saves the selected <x>", "is reference only", and the
# coverage-checkbox templates "records operation <x>" / "returns a validation response for" /
# "exercise operation ... through" / "rejects invalid input or succeeds" (a scenario that only
# names the op and asserts it "was recorded" proves nothing about behaviour) — hides the data.
# Enumerating vague phrases is a floor, not a ceiling (the semantic ASK below is the real
# arbiter); this catches the common ones cheaply. The data-in/out must be in the scenario.
EVERY $t IN $plan.trace WHERE $t.type IS "source"  AND  $t.path MATCHES ".*\.feature$"
THEN  $t.content NOT MATCHES "(?i)(Then .*(backed by the API|(are|is) visible|operations? (are|is) visible|controls are visible|operations? succeeds?|saves the selected|is reference only|records operation|returns a validation response for)|(When|Then) .*(exercise operation .* through|rejects invalid input or succeeds))"
  ELSE "a Gherkin scenario asserts vaguely (backed by the API / is-visible / records operation / returns a validation response / exercise-operation-through / rejects-or-succeeds) with no verifiable outcome — state the input record and the expected output values in the scenario (living documentation), not hidden in the step definitions"
```

```check scope=plan
# entity.op id leaked into Gherkin prose (deterministic): a Given/When/Then step that
# quotes a dotted operation id ("employee.create", "review.acknowledge") is code cosplaying
# as English — the scenario is written around the op id, not the business behaviour. The
# entity.op trace belongs in acceptance.md / step wiring, never in the sentence a reader
# reads. (A .feature *filename* or a src path is fine; this targets quoted dotted ids inside
# step lines.)
EVERY $t IN $plan.trace WHERE $t.type IS "source"  AND  $t.path MATCHES ".*\.feature$"
THEN  $t.content NOT MATCHES "(?im)^\s*(Given|When|Then|And) .*\"[a-z][a-z-]*\.[a-z][a-z-]+\""
  ELSE "a Gherkin step quotes an entity.op id (e.g. \"employee.create\") — that is code cosplaying as English; rewrite the step as business behaviour (\"When I register an employee: | name | ... |\") and keep the entity.op trace in acceptance.md / step definitions, not the scenario prose"
```

```check scope=plan
# Semantic (AI judgment) — the real arbiter a regex cannot be. Not every value-free step is
# vague ("returns conflict", "result is draft", "shows status active" are concrete outcomes);
# and a new vague phrasing the blocklist misses is still vague. The AI reads each behavioural
# Then and judges: does it assert a CONCRETE, VERIFIABLE outcome — a specific value, a named
# state, a rejection — that a reader can check, or is it presence-scanning ("...is visible",
# "saves the selected X") that proves the page mounted / the form submitted but not that the
# operation worked with real data?
EVERY $t IN $plan.trace WHERE $t.type IS "source"  AND  $t.path MATCHES ".*\.feature$"
ASK   "In ${$t.path}: does every behavioural Then step assert a concrete, verifiable outcome — a specific value the operation returned/persisted, a named lifecycle state, or a specific rejection — rather than a vague presence assertion (a control/page 'is visible', an operation 'is backed by the API', 'saves the selected X' with no value shown)? A UI scenario especially must state the record it acted on and the value it expects back, not just that a control rendered. List any scenario whose Then only scans the screen or asserts a generic success."
```

```check scope=plan
# entities = the entities this plan touched (from the manifest).
# featuresExist = the plan produced at least one Gherkin .feature file.
# This check: a plan with entities in scope must express behaviour as Gherkin scenarios,
# not only raw supertest/Playwright.
WHEN $plan.entities EXISTS
THEN  $plan.featuresExist IS "true"
  ELSE "no Gherkin .feature files produced — API/UI behaviour must be expressed as Cucumber scenarios, not only supertest/Playwright"
```

```check scope=plan subject="Test Scenarios" whenFailed="operations have no Gherkin scenario (untested)" whenPassed="operations have a scenario"
# covered = a .feature scenario exercises this operation (the entity + the op's
#   name/phrase are named by a scenario).
# This check: every operation (CRUD + lifecycle) needs its own scenario. The lifecycle
# ops (submit/acknowledge/close/cancel) surface here when untested.
EVERY $op IN $plan.expectedOperations
THEN  $op.covered IS "true"
  ELSE "operation has no Gherkin scenario — uncovered (needs its own .feature scenario); see ref"
```

# scope=system, NOT scope=plan: this iterates EVERY business rule in the app
# (specInstances is project-wide, independent of the plan's manifest — verified: the
# set populates the same under a plan or app-wide). A per-plan `evaluate` judges only
# what the plan owns; asking "does every rule in the whole app have a violation
# scenario" is a whole-app question that belongs to `mde review app` (--app-wide), not
# to a plan whose scope never touched most of those rules. Running it at evaluate blamed
# e.g. a client-contacts plan for untested employee-records rules it never authored.
```check scope=system subject="Business Rules" whenFailed="business rules are not exercised by a valid+invalid scenario pair (untested)" whenPassed="business rules have a valid+invalid scenario pair"
# A business rule is its own thing, not a property of an entity — it is scoped to its
# own file (every rule in the app, from specInstances). covered = a .feature file names
# the rule AND carries BOTH halves of the proof:
#   (a) an invalid case with rejection-oriented language
#       (reject/blocked/invalid/cannot/duplicate/…) that asserts a STRUCTURED rejection
#       carrying the rule's concept id (a rule/code/violation field), and
#   (b) a valid case that drives satisfying input and asserts the operation SUCCEEDS
#       with an observable effect.
# Naming the rule in a happy-path scenario does not count; a lone reject case does not
# count; the rule is only exercised when the pair shows it discriminating.
EVERY $rule IN $plan.expectedBusinessRules
THEN  $rule.covered IS "true"
  ELSE "business rule is not exercised by a valid+invalid pair — untested (needs, under tests/business-rules/, an invalid case asserting a structured rejection that carries the rule's concept id AND a valid case asserting the successful effect); see ref"
```

```check scope=plan subject="Business Rule Test Location" whenFailed="business-rule scenarios exist but not under tests/business-rules/" whenPassed="business-rule scenarios live under tests/business-rules/"
# inCorrectLocation = the SAME violation-scenario check as above, but scoped to ONLY
# tests/business-rules/*.feature (businessRuleFeatureBlob in model.mjs). A rule that is
# `covered` (found ANYWHERE) but not `inCorrectLocation` is tested, just in the wrong
# place — buried in a capability's regular operation .feature instead of the dedicated
# location. Only fires for rules that ARE covered; an uncovered rule is already reported
# by the check above and does not need a second, confusing "wrong location" complaint.
EVERY $rule IN $plan.expectedBusinessRules WHERE $rule.covered IS "true"
THEN  $rule.inCorrectLocation IS "true"
  ELSE "business rule has a violation scenario, but not under tests/business-rules/ — move it to tests/business-rules/{capability}.feature so every rule test lives in one dedicated location; see ref"
```

```check scope=plan
# featuresExist = the plan produced at least one Gherkin .feature file.
# packageJson = the raw package.json text the plan produced (root-most).
# This check: if the plan ships .feature files, they must be EXECUTABLE — the app must
# carry a Cucumber runner AND mde:test must run it. A .feature file with no cucumber
# dependency / no cucumber invocation in mde:test is a decorative trace file (names the
# op, passes presence/naming, but never runs). Step-definition presence is verified by
# the AI pass (requires knowing the runner's glue convention); this gate catches the
# common failure: .feature files exist but nothing executes them.
WHEN  $plan.featuresExist IS "true"
THEN  $plan.packageJson MATCHES "@cucumber/cucumber|cucumber-js" AND $plan.packageJson MATCHES "\"mde:test\"\s*:\s*\"[^\"]*cucumber"
  ELSE ".feature files are decorative — no Cucumber runner and/or mde:test does not execute them (scenarios named but never run); wire step definitions + run cucumber in mde:test"
```
