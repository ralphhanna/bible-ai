---
type: feature
id: business-transaction-analysis
title: Business transaction analysis
origin: mde
impacts:
  - business-requirements
  - ui-design
  - api-design
default: n/a
---

# Business transaction analysis

## Purpose

Verify that a use case represents a real, coherent business transaction rather than merely a
record operation. The analysis must identify the business condition that starts the work, the
business object that carries that condition, the actor action or decision, the resulting state
change, and how the original need is resolved, reduced, deferred, rejected, or recorded.

A structurally complete use case is still defective when its trigger disappears from the main
flow or its outcome only says that a record was created without explaining the business result.

## Impact on business-requirements

For every non-trivial use case, analyze and reconcile:

- **Business condition / need** — the real situation that causes the transaction.
- **Driving object** — the request, demand, case, order, application, review, work item, or other
  business object that represents and carries that need through the flow.
- **Result object** — the record created or changed to achieve the goal.
- **Supporting objects** — records selected, consulted, or validated.
- **Impacted objects** — records, balances, totals, availability, or lifecycle states materially
  changed by the transaction.
- **Business state change** — the before/change/after effect for the driving, result, and impacted
  objects.
- **Outcome reconciliation** — how the original business condition is resolved, partially
  resolved, deferred, rejected, or remains open.

The use case's trigger, preconditions, main flow, alternate flows, rules, objects, data changes,
and outcome must tell one causally connected story. A trigger naming one business need followed by
an unconstrained flow over unrelated records is a defect.

## Driving-object discovery

`Business Objects Involved` is not a flat noun list. Each object is classified as one or more of:

| Role | Meaning |
|---|---|
| Driving | Carries the business need and anchors the transaction |
| Result | Created or changed to achieve the goal |
| Supporting | Selected, consulted, or validated |
| Impacted | Materially changed as a consequence |

When a trigger, rule, flow step, quantity, or outcome refers to a durable concept with identity,
state, history, independent quantities, or lifecycle, determine whether the entity model is
missing a business object. Examples include demand, request, application, approval, case, order,
claim, reservation, or allocation need. Do not force such concepts into an existing result entity
merely because that entity is convenient to persist.

## Business-goal test

A use-case goal states the business result, not merely the storage or lifecycle operation.

Weak:

- Create a project assignment.
- Update a client.
- Change the review status.

Stronger:

- Fulfil all or part of an approved project staffing demand.
- Correct the client's current commercial profile.
- Complete and acknowledge the employee's performance review.

Record creation or status change belongs in the transaction result and state-change analysis.

## Trigger and use-case separation

A use case has one primary triggering business condition. Different triggers that require a
different driving object, starting decision, actor goal, or outcome normally become separate use
cases. Alternate flows vary the same transaction; they do not introduce a later lifecycle goal or
a materially different business transaction.

## Quantified fulfilment

Where a need is measured, define:

- requested amount and unit;
- fulfilled amount;
- remaining amount;
- whether fulfilment is partial or additive;
- whether several result records may fulfil one need;
- whether one result may fulfil several needs;
- over-fulfilment policy;
- reconciliation after cancellation, reversal, or completion.

This applies to staffing demand, orders, payments, capacity, inventory, budget, claims, quotas,
and similar transactions.

## Scenario evidence

Complex or quantified transactions include at least one representative business scenario showing
concrete before/change/after values. Add an edge scenario where it helps expose partial
fulfilment, exception handling, cancellation, concurrency, or insufficient capacity.

Example:

```text
Demand: Senior Developer, 60%, Jul-Dec
Candidate: Maria, 40% available
Result: 40% assignment created; demand remains open for 20%
```

Scenarios validate the business model and later seed acceptance examples; they do not replace the
use case or business rules.

## Template impact

- `use-case` template → driving/result/supporting/impacted object roles, state-change table, and
  representative scenarios for non-trivial transactions.
- `entity` template → no new section; missing-object findings update the existing entity model.

## Checks

- Does the main flow preserve the business condition named by the trigger and explicitly resolve,
  reduce, defer, reject, or record it in the outcome?
  · evidence: trigger + main flow + outcome
  · when: AI review
- Is the driving business object identified and carried through the transaction, or is its absence
  explicitly justified because the trigger is an immediate event with no durable business object?
  · evidence: use-case object roles + entity model
  · when: AI review
- Is the business goal expressed as a business outcome rather than only a record create/update or
  status-change operation?
  · evidence: Business Goal vs. Data Created / Changed / Viewed
  · when: AI review
- Are result, supporting, and materially impacted objects identified, with their resulting states
  reconciled?
  · evidence: object roles + state-change table + outcome
  · when: AI review
- Do durable concepts implied by needs, quantities, history, and lifecycle resolve to entities, or
  have a documented reason not to?
  · evidence: use-case wording vs. entity model + open questions
  · when: AI review
- Where fulfilment is quantified, are requested, fulfilled, remaining, multiplicity, and reversal
  semantics defined?
  · evidence: use case + rules + entity properties
  · when: AI review
- Does each complex transaction include a representative scenario that agrees with the use case,
  entity cardinalities, lifecycle, and business rules?
  · evidence: use-case scenarios
  · when: static + AI review
