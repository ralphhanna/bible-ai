---
id: open-questions-tracking
title: Open questions tracking
origin: mde
impacts:
  - business-requirements
default: n/a
---

# Open questions tracking

## Purpose

Keep important assumptions and unresolved questions **visible**, not hidden — incomplete
requirements are a defect when open questions are buried.

## Impact on business-requirements

Open and resolved business questions are tracked explicitly in `specs/business/discussion.md`
(entry schema) — the durable, project-level business discussion log — and surfaced rather than
silently assumed. Missing or deferred sections are marked explicitly instead of pretended
complete. **This is distinct from a plan's own `plans/<plan-id>/discussion.md`** (the
chronological plan-shaping trail that drives that plan's `pending-actions` flag and `mde review
app`'s per-plan open-discussion surfacing) — the two files serve different scopes and neither
substitutes for the other. A business question that outlives its originating plan belongs in
`specs/business/discussion.md`, not stranded in a closed plan's file.

**Per-artifact questions are mirrored into `specs/business/discussion.md`, not left stranded on
the artifact.** The entity/business-rule/role/use-case/capability-overview templates each carry
their own `## Open Questions` table — the natural place to *raise* a question while authoring
that artifact, in context. But `specs/business/discussion.md` is the only place a business
question is **tracked project-wide**: it is what a later plan or `mde review app` re-checks. So
every `## Open Questions` row added to an artifact **also** gets an entry in
`specs/business/discussion.md`, with a **back-reference to the artifact** (e.g. naming
`specs/business/entities/employee.md §Open Questions`). When the question is later resolved,
resolve it in `specs/business/discussion.md` and update the artifact's row to reflect the same
outcome — the two must never disagree, and a question left open on the artifact but absent from
`specs/business/discussion.md` (or vice versa) is drift.

## Template impact

- `discussion` template → open + resolved question entries in `specs/business/discussion.md`.
- entity / business-rule / role / use-case / capability-overview templates → `## Open
  Questions` rows, each mirrored into a `specs/business/discussion.md` entry.

## Checks

- Are important assumptions and open questions recorded in `specs/business/discussion.md`
  rather than hidden?
  · evidence: `specs/business/discussion.md`
  · when: static
- Are missing/deferred sections marked explicitly (not pretended complete)?
  · evidence: spec files' deferred markers
  · when: static
- Does every artifact `## Open Questions` row have a matching `specs/business/discussion.md`
  entry (open ↔ open, resolved ↔ resolved), and does every such entry back-reference the
  artifact it came from?
  · evidence: artifact `## Open Questions` rows vs. `specs/business/discussion.md` entries
  · when: static
