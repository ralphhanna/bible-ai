---
type: feature
id: semantic-references
title: Semantic references in generated text
origin: mde
impacts:
  - business-requirements
  - application-design
  - architecture
  - api-design
  - persistence-design
  - ui-design
  - documentation
default: on
---

# Semantic references in generated text

## Purpose

**All AI-generated specs and text output — specs (business and design), plans, reviews, knowledge
pages, reports, and walkthroughs — must tag references to known MDE objects with canonical
semantic tags**, so references are machine-resolvable, traceable, and linkable, not just prose that
happens to mention a name.

### Canonical tag form

A semantic reference is written `{{<kind>:<slug>}}` — `<kind>` a canonical MDE object kind,
`<slug>` the object's slug (the same slug used in its file path / id). Examples:
`{{entity:employee}}`, `{{use-case:approve-project-assignment}}`, `{{role:hr-administrator}}`,
`{{business-capability:performance-management}}`.

### Canonical object kinds

The `<kind>` vocabulary is **not defined here** — it is the closed set already owned by the manifest
trace schema's `sourceRef.kind` (`templates/trace/manifest-entry.schema.json`), the single source of
truth, so the tag vocabulary and the trace vocabulary never diverge. A tag whose `<kind>` is outside
that set is invalid; a new kind is added once, to the schema.

### Rules

- **Tag known objects.** Tag a named MDE object with `{{kind:slug}}` on first mention (and where a
  link/trace helps), rather than leaving it as bare prose.
- **Well-formedness.** Every tag present must parse as `{{<canonical-kind>:<slug>}}` and its slug
  must **resolve to a real object**. Malformed or dangling tags are defects.
- **Do not fabricate.** Never tag a reference to an object that does not exist — `{{entity:widget}}`
  with no `widget` entity is worse than untagged prose.
- **Prose stays readable.** The tag augments the reference; it does not replace readable naming.

This feature is also the **delivery mechanism**: the `## Impact` sections below carry the tagging
instruction into each text-producing target, so the convention is applied at generation — a plain
principle with no target impact is inert (the generator follows targets/templates).

## Impact on business-requirements

When generating business specs (overview, capabilities, entities, roles, rules, use cases,
glossary), **tag references to known MDE objects** with `{{kind:slug}}` on first mention (and where
a link/trace helps): entities `{{entity:<slug>}}`, roles `{{role:<slug>}}`, capabilities
`{{business-capability:<slug>}}`, use cases `{{use-case:<slug>}}`, business rules
`{{business-rule:<slug>}}`, operations `{{entity-operation:<entity>.<op>}}`. A spec that names
"Employee", "the Staffing Manager role", or "project-assignments capability" in prose without
tagging is drift — tag it. Do not fabricate a tag for an object that does not exist.

## Impact on application-design

Design-overview and decision text tags references to the business/design objects it names —
entities, capabilities, pages, use cases — as `{{kind:slug}}`, so design traces to the same
vocabulary the business specs use.

## Impact on architecture

Architecture narrative tags the entities, capabilities, and integrations it references
(`{{entity:…}}`, `{{business-capability:…}}`, `{{integration:…}}`) rather than naming them in bare
prose.

## Impact on api-design

API-design text tags the entities and operations its endpoints serve
(`{{entity:…}}`, `{{entity-operation:<entity>.<op>}}`).

## Impact on persistence-design

Persistence-design text tags the entities whose storage it describes (`{{entity:…}}`).

## Impact on ui-design

Page specs and the UI catalog tag the pages, entities, and capabilities they reference
(`{{web-page:…}}`, `{{entity:…}}`, `{{business-capability:…}}`).

## Impact on documentation

Docs, reports, knowledge pages, and walkthroughs tag references to known MDE objects with
`{{kind:slug}}` — a walkthrough of a use case tags `{{use-case:…}}` and the entities/roles it
walks through, so generated documentation links to the model rather than restating names.

## Checks

- Does generated text tag its references to known MDE objects with canonical `{{kind:slug}}`
  tags (rather than naming entities/roles/capabilities/use cases only in bare prose)?
  · evidence: generated spec/design/doc text vs. the objects it names
  · when: static
- Is every `{{...}}` tag well-formed — a canonical `<kind>` (per the trace schema) and a `<slug>`
  that resolves to a real object — with no dangling or fabricated references?
  · evidence: the tags vs. `specs/business/` + `specs/design/` objects
  · when: static

```check scope=item
# Well-formedness (deterministic): every {{...}} tag in a generated artifact must
# parse as {{<kind>:<slug>}}. Flags a malformed tag (missing kind or slug, spaces,
# empty). Completeness (did it tag what it should) and slug-resolves are the semantic
# checks above — a regex can't resolve slugs or judge untagged prose without false
# positives. This only fires on a present-but-malformed tag.
WHEN  $item.type IS "source"
  AND $item.content MATCHES "\{\{"
THEN  $item.content NOT MATCHES "\{\{\s*([^:}]+\}\}|:[^}]*\}\}|[^:}]*:\s*\}\}|\s*\}\})"
  ELSE "a {{...}} semantic tag is malformed — use {{<kind>:<slug>}} with a canonical kind and a resolvable slug (semantic-references)"
```
