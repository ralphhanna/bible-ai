---
id: business-rule-catalogue
title: Business rule catalogue
origin: mde
impacts:
  - business-requirements
default: n/a
---

# Business rule catalogue

## Purpose

Capture business rules specifically enough to become validation logic, decision logic, test
cases, or user-facing warnings.

## Impact on business-requirements

Each rule defines: rule ID, statement, owning/primary capability, affected entities, trigger
or context, constraint/decision/calculation, exceptions, and a testability note.
Cross-capability rules live at `specs/business/rules/<slug>.md`; capability-owned rules under
`capabilities/<slug>/business-rules/<slug>.md`. One file per rule. Access control is **not** a
business rule — it is an attribute of the entity operation (see `entity-operations-and-access`).

## Template impact

- `business-rule` template → rule fields (statement, capability, entities, trigger,
  constraint, exceptions, testability).

## Checks

- Does each rule have a statement, owning capability, affected entities, trigger, the
  constraint/decision/calculation, exceptions, and a testability note?
  · evidence: rule files under `specs/business/rules/` or `capabilities/<slug>/business-rules/`
  · when: static
- Are rules associated with a capability/entity (not orphaned)?
  · evidence: rule frontmatter / links
  · when: static
