---
type: feature
id: capability-design
title: Capability design
origin: mde
impacts:
  - application-design
default: n/a
---

# Capability design

## Purpose

For each in-scope capability, name what it needs to be built: its primary entity, APIs,
pages, and modules.

## Impact on application-design

`specs/design/capabilities/<slug>/overview.md` names the capability's primary entity and the
APIs, pages, and modules it needs. Design specs cover every in-scope capability and its
primary entity. Each design artifact traces to business specs.

## Template impact

- `capability` design template → primary entity + APIs + pages + modules.

## Checks

- Does design specs cover every in-scope capability and name its primary entity, APIs, pages,
  and modules?
  · evidence: `specs/design/capabilities/<slug>/overview.md`
  · when: static
