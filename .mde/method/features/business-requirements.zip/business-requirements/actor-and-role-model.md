---
id: actor-and-role-model
title: Actor and role model
origin: mde
impacts:
  - business-requirements
default: n/a
---

# Actor and role model

## Purpose

Define who uses the system and what they may do, at the business level — the role ids later
referenced by entity operations (access control) and the role/user switcher.

## Impact on business-requirements

Each actor/role defines: name, responsibility, business goals, capabilities used, and key
permissions/constraints at the business level. Roles stay **shared** at the top level
(`specs/business/roles/<role-slug>.md`), one file per role, never duplicated inside a
capability. Role ids are the join key entity operations reference for permitted roles.

## Template impact

- `role` template → actor/role definition fields.

## Checks

- Does each role define responsibility, goals, capabilities used, and business-level
  permissions/constraints?
  · evidence: `specs/business/roles/<role-slug>.md`
  · when: static
- Are roles shared at the top level (not duplicated inside capabilities)?
  · evidence: roles directory layout
  · when: static
