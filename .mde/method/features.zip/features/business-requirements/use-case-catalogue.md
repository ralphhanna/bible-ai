---
type: feature
id: use-case-catalogue
title: Use case catalogue
origin: mde
impacts:
  - business-requirements
default: n/a
---

# Use case catalogue

## Purpose

Capture capability-scoped use cases that drive business design, page specs, prototype behaviour,
interaction diagrams, implementation, and tests. A use case describes a coherent business
transaction, not merely an entity operation or a list of UI steps.

## Impact on business-requirements

Each use case is **capability-scoped** and defines:

- use case ID / short name;
- capability;
- business goal;
- primary actor and participating supporting actors;
- one primary trigger;
- preconditions;
- main business flow;
- alternate flows and exceptions;
- business rules used;
- business objects classified as driving, result, supporting, and impacted;
- data viewed / created / changed;
- resulting business state and outcome;
- audit/history needs;
- open questions;
- design handoff notes;
- representative scenarios for complex or quantified transactions.

One file per use case under
`specs/business/capabilities/<slug>/use-cases/<slug>.md`.

## Business transaction coherence

The trigger, flow, and outcome must be causally connected:

```text
business condition or need
→ driving business object
→ actor action or decision
→ business state change
→ need resolved, reduced, deferred, rejected, or recorded
```

The driving business object introduced by the trigger remains visible through the main flow and
outcome. When the trigger is an immediate event with no durable object, the use case states that
explicitly.

The Business Goal states the business result. Creating or updating a record is normally the
mechanism or result, not the goal itself.

## Trigger discipline

A use case has one primary triggering business condition. A trigger joined with `or` is reviewed
for accidental combination of different transactions. If the alternatives require different
starting objects, actors, decisions, flows, or outcomes, split them into separate use cases.

## Actor participation

Every supporting actor must participate in the flow by supplying information, deciding,
approving, confirming, receiving, or being notified. A named actor with no interaction is removed
or the missing interaction is added.

The primary actor must have the business authority needed to achieve the declared outcome. If
another actor must approve or confirm it, the flow and resulting status say so.

## Preconditions and entry consistency

Every object or condition required by the first substantive flow step is established by:

- the trigger;
- a precondition; or
- an explicit early retrieval or creation step.

Do not silently rely on an unstated request, demand, approval, availability view, or prior state.

## Main-flow discipline

The main flow:

- follows the primary actor's business goal;
- carries the driving object through the transaction;
- names material system decisions and validations;
- identifies when supporting actors participate;
- states the commit or business decision;
- reconciles the result and materially impacted objects.

UI control details belong in Page Spec panels/actions unless they are necessary to explain the
business transaction.

## Alternate-flow discipline

An alternate flow:

- branches from a named main-flow step or condition;
- pursues the same business goal;
- returns to the main flow or produces an alternate outcome for the same transaction.

Subsequent lifecycle operations such as cancel, complete, reopen, or revise normally become their
own use cases unless they are truly branches before the original transaction completes.

## State-change analysis

For non-trivial or multi-object transactions, include a structured state-change table:

| Object | Before | Change | After |
|---|---|---|---|

The table covers the driving object, result object, and materially impacted objects. It must agree
with `Data Created / Changed / Viewed`, lifecycle operations, rules, and Outcome.

## Rules and lifecycle consistency

Every validation, decision, eligibility test, calculation, exception, approval requirement, and
state guard in the flow resolves to:

- a business rule; or
- an entity lifecycle operation/guard.

Every lifecycle action named in the use case resolves to a valid source state, operation, permitted
actor, guard, and resulting state. Important lifecycle operations should be exercised by at least
one use case or explicitly declared administrative/system-only.

## Open-question challenge

`Open Questions: None` is accepted only after checking unresolved decisions about:

- driving and result object boundaries;
- actor authority and approval;
- quantities and fulfilment;
- relationship cardinality;
- lifecycle ownership;
- exceptions and override authority;
- cancellation/reversal impact;
- concurrency and stale information where material.

Questions discovered in the use case are mirrored into the plan's `discussion.md` through
`open-questions-tracking`.

## Template impact

- `use-case` template → the use-case fields, object-role classification, state-change table, and
  representative scenarios.

## Audit

Judge whether each use-case describes **the real business behaviour**, or is generic
"transaction" scaffolding that would fit any entity. There is no running app — read each
use-case's main flow against the domain it claims to capture.

The tell of a fake flow is **abstract placeholder language**: steps like "the actor starts
the transaction", "selects or supplies the driving object", "the result object is created or
updated", "impacted objects are reconciled" — filler that names no concrete field, state, or
decision. A real flow names *what actually happens*: which fields change, which status
transitions (e.g. active → inactive), what the referenced rule actually checks *at that step*
(not just a list of rule ids), what the actor sees and confirms, what is recorded. Compare
use-cases across the app: if every flow reads as the same six generic sentences with only the
entity name swapped, they are template shells.

Report each use-case as **concrete** (a builder could implement it without inventing the
behaviour) or **generic** (transaction boilerplate — sections filled, behaviour unspecified).
A use-case with all sections present but a placeholder flow is not a real requirement.

## Checks

- Is each use case capability-scoped, with business goal, actor(s), one primary trigger,
  preconditions, main + alternate/error flows, rules, object roles, data changes, outcome,
  audit/history, open questions, and design handoff?
  · evidence: use-case files under `capabilities/<slug>/use-cases/`
  · when: static
- Is every use case associated with a capability rather than left unscoped?
  · evidence: use-case location / frontmatter
  · when: static
- Does the main flow begin from the business condition and driving object established by the
  trigger/preconditions, and does the outcome reconcile that condition?
  · evidence: Trigger + Preconditions + Main Business Flow + Outcome
  · when: AI review
- Is the Business Goal a business result rather than merely `create/update/delete/change status`
  on a record?
  · evidence: Business Goal vs. Data Created / Changed / Viewed
  · when: AI review
- Does every supporting actor have an explicit participation in a flow, approval, confirmation,
  notification, or decision?
  · evidence: actor list vs. flows
  · when: static + AI review
- Does each alternate flow branch from the same transaction rather than introduce an unrelated
  or later lifecycle goal?
  · evidence: alternate-flow branch references + outcomes
  · when: AI review
- Do lifecycle actions and business decisions resolve to declared entity operations and business
  rules?
  · evidence: use case vs. entity Operations / Lifecycle and rule files
  · when: static + AI review
- For complex or quantified use cases, is there a state-change table and at least one concrete
  scenario consistent with entities, cardinalities, rules, and outcome?
  · evidence: use-case state-change/scenario sections
  · when: static + AI review
