---
id: use-case-catalogue
title: Use case catalogue
origin: mde
impacts:
  - business-requirements
default: n/a
---

# Use case catalogue

## Purpose

Capture capability-scoped use cases that drive page specs, prototype behaviour, interaction
diagrams, and tests.

## Impact on business-requirements

Each use case is **capability-scoped** and defines: use case ID, capability, primary actor,
user/business goal, preconditions, main flow, alternate/error flows, business rules used,
entities affected, likely pages / UI-catalog entries, and expected outcome. One file per use
case under `specs/business/capabilities/<slug>/use-cases/<slug>.md`.

## Template impact

- `use-case` template → the use-case fields.

## Checks

- Is each use case capability-scoped, with actor, goal, preconditions, main + alternate/error
  flows, rules used, entities affected, likely pages, and expected outcome?
  · evidence: use-case files under `capabilities/<slug>/use-cases/`
  · when: static
- Is every use case associated with a capability (not unscoped)?
  · evidence: use-case location / frontmatter
  · when: static
