---
id: capability-definition
title: Capability definition
origin: mde
impacts:
  - business-requirements
default: n/a
---

# Capability definition

## Purpose

Capabilities are the vertical slices that organize the business/application — the unit that
later drives the API boundary, source-code module, and test scope. **"Capability" is the term;
do not relabel capabilities as "areas" or rename them** — refer to each by its defined name
(e.g. `employee-records`, `performance-management`), never an invented grouping label.

## Impact on business-requirements

Each capability defines: capability ID, name, business purpose, primary actors, business
outcomes, primary entity (when applicable), related entities/rules/use-cases/pages, related
APIs or integration boundaries when relevant, and implementation/design status. A capability
may use many entities but identifies a **primary** entity when that helps define boundaries.
One file per capability under `specs/business/capabilities/<slug>/overview.md` — never a flat
`capabilities.md`.

## Template impact

- `capability-overview` template → the capability definition fields.

## Checks

- Does each capability define purpose, primary actors, outcomes, and (when applicable) a
  primary entity, with related entities/rules/use-cases/pages linked?
  · evidence: `specs/business/capabilities/<slug>/overview.md`
  · when: static
- Are capabilities specific (not missing or too generic), each with a business outcome?
  · evidence: capability overview files
  · when: static
